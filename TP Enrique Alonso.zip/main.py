
import random
import time
import datetime
from operator import itemgetter


#Metodos para facilitar las tareas
def leerArchivo(archivo):
    file = open(archivo, "r") 
    instancias= file.read().splitlines()
    file.close() 
    return instancias


def procesarInstancia(cantidad):
    for x in range(1,4):
        for long in ['300','500','700']:
            instancias=leerArchivo("instancias/texto_mas_parecido_" + str(cantidad) + "_" + long + "_" +str(x) + ".txt")
            tp=TrabajoPractico(instancias)
            salida= tp.busquedaGrasp(5000)
            print ("SOLUCION GRASP :" + str(salida))

def procesarPorLongitud(longitud):
    
    for cantInstancias in [10,15,20]:
        for x in range(1,4):            
            instancias=leerArchivo("instancias/texto_mas_parecido_" + str(cantInstancias) + "_" + str(longitud) + "_" +str(x) + ".txt")
            tp=TrabajoPractico(instancias)
            salida= tp.busquedaGrasp(1000)
            print ("SOLUCION GRASP :" + str(salida))            



class TrabajoPractico():

    #Inicio Manero de estadisticas

    def crearEstadisticasVacias(self,largo):
        #Inicializa estadistica sobre ocurrencias de caracteres en una cadena
        estadisticas=[]
        
        for pos in range (0, largo):
            estadisticas.append({})
                
        return estadisticas
    

    def popularEstadistica(self,cadena,estadisticas):
        #Retorna una estadistica completa donde por cada posicion tengo las cantidades que aparece cada caracter
        
        for pos in range (0, len(cadena)):
            if cadena[pos] in estadisticas[pos]:
                estadisticas[pos][cadena[pos]]+=1
            else:
                estadisticas[pos][cadena[pos]]=1
        
        return estadisticas
    
    #Fin manejo Estadisticas



    
    def goloso(self):
        #Retorna una solucion segun las maximas repeticiones de caracteres para el conjunto de instancias. 

        estadisticas=self.crearEstadisticasVacias(len(self.instancias[0]))

        for unaInstancia in self.instancias:
            estadisticas= self.popularEstadistica(unaInstancia,estadisticas)   

        palabra=""
        for stat in estadisticas:
            palabra=palabra+max(stat, key=stat.get)
        return palabra

    def golosoAleatorio(self):
        #Retorna una solucion aleatoria basado en el conjunto de instancias

        estadisticas=self.crearEstadisticasVacias(len(self.instancias[0]))

        for unaPalabra in self.instancias:
            estadisticas= self.popularEstadistica(unaPalabra,estadisticas)   

        palabra=""
        for stat in estadisticas:
            palabra=palabra+str(random.choice(list(stat.keys())))       
        return palabra


    def golosoAleatorioMejorado(self):
        #Retorna una solucion aleatoria basado en valores tomados en las instancias
        #utiliza un umbral para generar soluciones aleatorias pero utilizando ocurrencias >= 25%
        estadisticas=self.crearEstadisticasVacias(len(self.instancias[0]))
        porcentajeDefinido=25

        for unaPalabra in self.instancias:
            estadisticas= self.popularEstadistica(unaPalabra,estadisticas)   

        palabra=""
        for stat in estadisticas:
            cantidadOcurrenciasUmbral = sum(stat.values())*porcentajeDefinido/100
            letrasQueCumplenUmbral=[]
            
            for clave in stat.keys():
                if stat[clave]>=cantidadOcurrenciasUmbral:
                    letrasQueCumplenUmbral.append (clave)
            
            #Si nada cumple ese umbral puede usar cualquier caracter que este en esa posicion
            if letrasQueCumplenUmbral==[]:
                letrasQueCumplenUmbral=list(stat.keys())
            
            palabra=palabra+str(random.choice(letrasQueCumplenUmbral))
        return palabra


    def obtenerCaracteres(self):
        caracteres = set()
        for each in self.instancias:
            for char in list(each):
                caracteres.add (char)
        return list(caracteres)

    def __init__(self,instancias):
        self.instancias=instancias
        self.caracteres=self.obtenerCaracteres()
    


    def getDistancia(self,palabra,solucion):
        #Retorna la distancia entre la solucion y una de las cadenas de la instancia
        palabraList=list(palabra)
        solucionList=list(solucion)
        distancia=0
        for x in range(0,len(palabra)):
            if solucionList[x]!=palabraList[x]:
                distancia+=1
        return distancia

    def valor(self,solucion):
        #Dada una solucion retorna la distancia maxima respecto a todas las instancias
        maxDistancia=0
        for each in self.instancias:
            distancia=self.getDistancia(each,solucion)
            if distancia>maxDistancia:
                maxDistancia=distancia

        return maxDistancia


    def getDistanciaOptimizada(self,instancia,caracter,posicion):
        #Retorna la distancia entre la solucion y una de las cadenas de la instancia
        palabraList=list(instancia)
        if palabraList[posicion]==caracter:
            return -1
        else:
            return 1


    def valorRelativoASolucion(self, valorSolucionPrecedente, caracter, posicion):
        #Dado un caracterModificado y una posicion donde se cambio ese caracter retorna el nuevo valor de distancia maxima
        maxDistancia=0
        for unaInstancia in self.instancias:
            distancia= valorSolucionPrecedente + self.getDistanciaOptimizada(unaInstancia,caracter,posicion)
            if distancia>maxDistancia:
                maxDistancia=distancia

        return maxDistancia


        
    def variacionesEnPosicion(self,solucion,posicion):
        #Retorna variaciones de caracteres a la solucion dada una posicion de esta ultima
        
        solucionList=list(solucion['solucion'])     #convierte un string en una lista de strings
        caracterSolucionOriginal=solucionList[posicion]
        
        
        salida=[]
        for caracterNuevo in self.caracteres:
            if caracterNuevo!=caracterSolucionOriginal:
                solucionList[posicion]=caracterNuevo
                
                unaSolucion= "".join(solucionList)
                
                salida.append({'solucion':unaSolucion,'valor':self.valorRelativoASolucion(solucion['valor'], caracterNuevo, posicion)})
                
        
        return salida


    def vecindad (self,solucion):
        #Retorna una vecindad completa ordenada de mejor solucion a peor solucion
        vecinos=[]
        for pos in range(0,len(solucion['solucion'])):
            vecinos += self.variacionesEnPosicion(solucion,pos)   
                   
        return sorted(vecinos, key=itemgetter('valor'),reverse=False)

    def busquedaVecindad(self,solucion):
        #Retorna el mejor vecino de la vecindad

        vecinos=self.vecindad(solucion) #retorna lista de diccionario

        v=iter(vecinos)
        solucionVecina=next(v)
        
        while solucionVecina['valor'] < self.valor(solucion['solucion']) and v!=None:
            solucion=solucionVecina
            solucionVecina=next(v)
        return solucion


    def busquedaLocal(self,solucion):
        #Realiza la busqueda local apartir de una solucion y un conjunto de instancias
        mejorSolucion = {'solucion':solucion,'valor':self.valor(solucion)}   #convierto una cadena en una solucion
        vueltas=0
        primeraIteracion=True
        solucionVecina=self.busquedaVecindad(mejorSolucion)
        while (primeraIteracion or (solucionVecina['valor'] < mejorSolucion['valor'] and mejorSolucion['solucion']!=solucionVecina['solucion'])) and vueltas<1000:
            primeraIteracion=False
            
            mejorSolucion= solucionVecina
            solucionVecina = self.busquedaVecindad(mejorSolucion)
            vueltas+=1
        return mejorSolucion
    
    def busquedaGrasp(self,iteraciones):
        f = open("estadisticas.txt", "a")
        
        mejorSolucion=None
        
        for x in range (0,iteraciones):
            tiempoProcesoIni= time.time()
            solucion=self.golosoAleatorioMejorado()
            
            nuevaSolucion= self.busquedaLocal(solucion)
            if mejorSolucion==None or nuevaSolucion['valor']<mejorSolucion['valor']:
                    mejorSolucion=nuevaSolucion

            
            tiempoProceso= time.time() - tiempoProcesoIni
            f.write("{0}/{1},{2},{3},{4}\n".format(x+1,iteraciones,nuevaSolucion['valor'],mejorSolucion['valor'],tiempoProceso))     
        f.close()
        
        self.guardarArchivoSolucion(mejorSolucion)
        
        return mejorSolucion


    def guardarArchivoSolucion(self,solucion):
        output = open("out_" + datetime.datetime.now().strftime("%Y%m%d%H%M%S") +".txt", "w")
        output.write("{0}\n{1}\n".format(solucion['solucion'],solucion['valor']))     
        output.close()



if __name__ == "__main__":

    #Dependiendo del caso, la solucion se mostrada en pantalla como la cadena de texto o tambien como una solucion y su valor
    
    #Se instancian los archivos que luego pueden ser utilizados por cualquier metodo de la clase TrabajoPractico
    instancias=leerArchivo("instancias/texto_mas_parecido_20_300_2.txt")
    
    
    tp=TrabajoPractico(instancias)

    # Ejercicio 1
    print (tp.goloso())

    # Ejercicio 2
    print (tp.golosoAleatorio())

    # Ejercicio 3
    #Tener en cuenta que esta solucion debe ser una solucion posible de la instancia cargada o seleccionada.
    unaSolucion="cgtgggtaaggcctcactttactatttaactagcggcgcttgtgtaagcgttgggcaggtcgtggggatccatcgttcgacgcgatatcaaatcatcgatcggaagaatatccagtagggtaaacacacgatgtctcattggggtttatgggtctacgagttgtctgtaagatgaggatctatatgcgtccccaggtcgagtgagagtctgtgtaaacttctgcacgggagcaagcgggcccaaatgggggggcagcatattgctcggctgtaaaagttgacgagaaatccgtccagtgt"
    print (tp.busquedaLocal(unaSolucion))


    #Ejercicio 5
    #Retorna la mejor solucion encontrada y tambien la guarda en archivo segun fue solicitado
    print (tp.busquedaGrasp(1000))
    
    
    
    
    
    #Algunas referencias sobre como ejecutan la corrida grasp sobre multiples archivos al mismo tiempo:
    #Para archivos de biotecnologia.
    #procesarInstancia(10)
    #procesarInstancia(15)
    #procesarInstancia(20)

    #procesarPorLongitud(300)
    #procesarPorLongitud(500)
    #procesarPorLongitud(700)


    #Adicionalmente cada ejecucion generara y completara un archivo estadisticas con todas las corridas en el orden realizado.
    

  
    
